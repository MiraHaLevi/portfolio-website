# Mira Halevi — Portfolio

Static site. No build step.

## Publish on GitHub Pages

1. Create a repository and upload the **contents of this folder** to its root.
2. Repo **Settings → Pages** → Source: *Deploy from a branch* → Branch: `main`, folder: `/ (root)` → Save.
3. The site goes live at `https://<username>.github.io/<repo>/` in a minute or two.

Using a custom domain: add it under Settings → Pages → Custom domain.

## Files

- `index.html` — home page (entry point)
- `*.dc.html` — the other pages (Work, About, Contact, and one per project)
- `assets/img/` — all project photography
- `assets/logo/` — the mira logomark
- `images.js` + `image-slot.js` — map slot ids to exported image files
- `_ds/` — design system tokens and stylesheets
- `support.js`, `cursor.js` — page runtime
- `.nojekyll` — **required**: stops GitHub Pages from hiding the `_ds` folder

## Replacing an image

Overwrite the file in `assets/img/` keeping the same filename, or edit the path in `images.js`.

## Note

The published site loads React from unpkg.com, so it needs an internet connection. Uploads and in-page editing are editor-only features and are not part of this export.
