# Mira Halevi — Design System

Design system for **Mira Halevi's portfolio website** — an independent brand designer and creative strategist. The site exists to get her hired/hired-for-projects by employers, agencies, and clients in branding and marketing; it needs to read as premium, highly-crafted, and confident without tipping into corporate or overly experimental territory.

## Sources

This is a **from-scratch** build — no Figma file, codebase, or existing site was attached. The only supplied asset is a logomark:

- `uploads/logo-1784054215225.svg` — the "mira" wordmark mark, copied into `assets/logo/` in ink/white/pink/green fills.

Everything else (palette, type system, component set, UI kit copy) was designed from the brief below and is a first pass, meant to be iterated with real input.

**Brief, as given:** thoughtful, refined, approachable, highly crafted. Bright, elegant, modern, minimal, confident, friendly, creative, sophisticated, interactive. Predominantly white. Avoid corporate or overly experimental. Accent direction: pinks and greens. Type direction: a single confident sans (no serif pairing). Sections needed: Home, Work index, Case study, About, Contact.

## Font substitution — please read

No font files were supplied. **Manrope** (body/UI) and **Newsreader** (serif headings) — plus **IBM Plex Mono**, reserved for future code/meta use — are loaded from Google Fonts as a considered pairing for "confident geometric sans + elegant editorial serif." This is a placeholder choice — if there's a licensed or preferred typeface, upload the font files and this system should be updated to self-host them.

## Intentional additions

No component source was provided, so the system uses a from-scratch primitive set sized to a portfolio site's actual needs (not a generic app kit): `Button`, `Badge`, `Card`, `Input`, `Textarea`, `Checkbox`, `Tabs`, `Tooltip`, `Toast`, `Dialog`. Left out on purpose: Select, Radio, Switch, Avatar — nothing in the brief calls for them yet.

## Content fundamentals

- **Voice:** first person, warm and direct. "I build brands people actually remember," "I read every note myself." Confident without corporate hedging — no "leverage," "solutions," "synergy."
- **Casing:** sentence case everywhere — headlines, nav, buttons, badges. No ALL CAPS except the small uppercase eyebrow labels (e.g. "Branding & Creative Strategy"), which use letter-spacing instead of shouting.
- **Punctuation as rhythm:** short declarative sentences, em dashes for asides ("a good idea into an identity worth trusting"), periods over exclamation points.
- **Address:** speaks to the reader as "you" in CTAs ("Have a brand problem worth solving?") and about herself as "I" elsewhere — never "we" (she's independent) and never third person about herself.
- **No emoji, no filler stats.** Copy earns its place; no "10+ years," "50 happy clients" padding unless it's a real, specific number.
- **CTAs are verbs, not nouns:** "Start a project," "Get in touch," "See all work" — never "Submit" or "Learn more."

## Visual foundations

**Color.** Predominantly white/paper. Two accents only: a dusty, muted rose-red (`--pink-500`) for primary CTAs, links, and category tags; a deep forest green (`--green-600`/`--green-900`) as the secondary accent and the one dark surface in the system (footer, callouts). Neutrals are warm, never pure black/white — `--ink` is a warm near-black, `--paper` a warm off-white. See the Colors cards for the full ramps.

**Type.** Headings are set in Newsreader, a serif, at medium-weight italic for warmth and editorial confidence; body copy, UI labels, captions, and buttons stay on Manrope (sans) for clarity and friendliness — the pairing is the deliberate "refined heading voice / approachable body voice" contrast. No italics in the sans family — emphasis there comes from weight or color.

**Spacing.** 4px base unit, roughly doubling from 4 → 192px. Section rhythm uses the large end of the scale (64–128px vertical padding between sections); component internals use the small end (8–24px).

**Backgrounds.** No gradients, no patterns, no textures. Full-bleed white is the default; the paper and pale-pink tints break up long pages; the single dark-green surface (site footer / closing CTA) is the one deliberate contrast moment per page.

**Imagery.** Full-bleed or sharp-cornered rectangular crops (never rounded) — photography should feel considered and gallery-like, warm-neutral color grading, minimal grain. No stock-photo gloss. (No real photography was supplied; the UI kit uses `<image-slot>` drop targets everywhere a photo belongs — see "Iconography & imagery" below.)

**Animation.** Ease-out only (`cubic-bezier(.16,1,.3,1)`) — motion settles, never bounces or overshoots. Fast micro-interactions (150ms) for buttons/toggles, base (280ms) for reveals and page-section transitions, slow (480ms) for image hovers. Page-to-page navigation in the UI kit fades/lifts (~220–320ms) rather than hard-cutting.

**Hover states.** Primary buttons darken one step (`--pink-500` → `--pink-600`); secondary/outline buttons invert to a solid ink fill; ghost/text links draw an underline in from the left; project-card images scale up ~4.5% and the title's arrow glyph slides in from the left. The primary nav CTA has a subtle magnetic pull toward the cursor.

**Press states.** Buttons scale to 97% on `:active` — no color-only presses.

**Borders & dividers.** Hairline (1px) warm-neutral lines (`--line`) — used sparingly, mostly as list/table dividers and card outlines, never as a heavy structural element.

**Shadows.** Nearly flat. A soft, warm-toned shadow only lifts true overlays (dialogs, toasts) — cards and buttons stay shadow-free, relying on whitespace and color for hierarchy.

**Corner radius — the signature contrast.** UI chrome (buttons, badges, form fields, dialogs) is generously rounded (pill buttons/badges, 12–28px on cards/dialogs). Photography and case-study imagery is always sharp, 0-radius rectangles — the contrast between soft interface and crisp image is a deliberate brand signature.

**Transparency & blur.** Used in exactly two places: the sticky header (translucent white + blur, so content scrolls underneath it) and the dialog scrim (dark, blurred). Not used decoratively elsewhere.

**Layout rules.** Centered content column, `max-width: 1320px` with a responsive gutter; a narrower 760px column for long-form case-study text. Header is sticky; footer is a fixed dark closing block on every page.

## Iconography

No icon library or icon font was supplied. The system deliberately keeps icon use minimal and text-forward:

- The only "icons" in the kit are a handful of single-stroke UI marks (checkmark in `Checkbox`, close glyph in `Dialog`) drawn as plain inline SVG paths, and a unicode arrow (→) used for hover-reveal affordances and inline links. These match the rounded, single-weight geometry of the logo mark.
- No emoji, no unicode symbols as decoration.
- If the site grows into needing a real icon system (e.g. social glyphs, a richer nav), pull a CDN icon set with a similarly geometric/rounded stroke (Phosphor or Feather are good starting candidates) rather than hand-drawing more — flagging this as a future need rather than inventing one now.
- The only real visual asset is the logomark (`assets/logo/`); no other illustrations or photography were supplied, so all photography slots in the UI kit are `<image-slot>` drop targets, not generated or placeholder imagery.

## Components

`components/core/` — `Button`, `Badge`, `Card`
`components/forms/` — `Input`, `Textarea`, `Checkbox`
`components/navigation/` — `Tabs`
`components/feedback/` — `Tooltip`, `Toast`
`components/overlay/` — `Dialog`

## UI kit

`ui_kits/portfolio/` — an interactive click-through recreation of the portfolio site: Home, Work (filterable index), Case Study (template), About, Contact — all wired together via `App.jsx`'s in-page router. Open `index.html`.

## Index

- `styles.css` — root stylesheet, imports everything under `tokens/`
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `radius-shadow.css`, `motion.css`
- `assets/logo/` — the "mira" logomark in ink/white/pink/green
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand/Motion)
- `components/` — reusable primitives, listed above
- `ui_kits/portfolio/` — the click-through site recreation
- `thumbnail.html` — homepage tile for this design system
- `SKILL.md` — portable skill definition for use in Claude Code

## Caveats & ask

- **No real work to show yet.** The Work grid, case study, and About portrait all use placeholder `<image-slot>` drop targets and fictional client names (Aster Wellness, Nordly Coffee, etc.) — drop in real project photography and swap the sample copy in `ui_kits/portfolio/data.js` as soon as it's ready.
- **Font is a placeholder.** Manrope was chosen as the closest free match to the logo's geometry — confirm it or supply real font files.
- **Palette is a first pass** on "pinks and greens" — happy to push warmer/cooler, more saturated/muted, or add a third accent once there's real work to calibrate against.
- **Bio/resume copy is invented** for demonstration — replace with real background, experience, and a real resume link.

Tell me what's working and what isn't and I'll iterate — this is a first draft meant to be pushed on.
